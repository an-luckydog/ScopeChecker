package com.ttpfx.service;

import com.ttpfx.entity.UserLog;

/**
 * @author ttpfx
 * @date 2023/3/29
 */
public interface UserLogService{

    boolean save(UserLog userLog);
}
